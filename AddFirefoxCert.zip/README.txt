Readme for AddFirefoxCert
=========================


Installation instructions:

1. Copy the folder "Firefox-certificate-and-certutil" to a location on your server accesable by all users
2. Copy the "AddFirefoxCert.cmd" file to your login scripts folder and ensure that it is called during login for a normal user
3. Copy your internal CA (or whatever cert you want to distribute to your domain users) to the "Firefox-certificate-and-certutil" folder